def numbers_isint(x):
    if type(x) == int:
        return True
    else: return False

def numbers_max(x, y):
    if x > y :
        return x
    else:
        return y

def numbers_func(x):
    return (((x ** 2) - (x + 2)) * 2)
