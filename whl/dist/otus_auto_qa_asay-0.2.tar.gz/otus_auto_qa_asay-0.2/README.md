# otus_auto_qa
Projects for Otus "Automation of web-testing" course (03-08.2019)
