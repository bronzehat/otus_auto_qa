def lists_append(x):
    li = []
    for i in range(x):
        li.append(i)
    return (li)

def lists_length(l):
    return len(l)

def lists_reverse(l):
    return (list(reversed(l)))